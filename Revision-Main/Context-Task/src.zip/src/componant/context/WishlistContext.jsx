import React from "react";

const WishlistContext = React.createContext();
export const ProductContext = React.createContext();

export default WishlistContext;
