import React from "react";

const RecipeReducer = (state, action) => {
  switch (action) {
  }
};

export default RecipeReducer;
